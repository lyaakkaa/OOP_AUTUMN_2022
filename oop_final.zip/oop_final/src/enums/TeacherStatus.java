package enums;

public enum TeacherStatus {
	ASSISTANT, LECTURER, SENIOR_LECTURER, PROFESSOR
}
