package enums;

public enum ManagerType {
	DEPARTMENTS, OR
}

