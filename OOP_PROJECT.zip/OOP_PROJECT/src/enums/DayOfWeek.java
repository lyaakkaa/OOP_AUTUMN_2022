package enums;

public class DayOfWeek {

}
