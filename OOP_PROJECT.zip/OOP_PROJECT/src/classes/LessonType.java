package classes;

public class LessonType {

}
