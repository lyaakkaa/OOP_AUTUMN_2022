package classes;

public class News {

}
