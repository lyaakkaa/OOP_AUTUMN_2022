package classes;

public class Course {

}
