package comparator;

public class ComparatorGPA {

}
