package testik;

import java.io.IOException;


import classes.*;
import enums.Degree;
import enums.Faculty;
import enums.ManagerType;
import enums.TeacherStatus;
import exceptions.WrongLoginException;

public class Main {
	public static void main(String[] args) throws InterruptedException, IOException, WrongLoginException{

		Admin a = new Admin("Ainash", "J", "123", 100000, 0.7);
		Manager m = new Manager("Akmi", "Sag", "amina123", 90000,1,ManagerType.OR);
		Student st2 = new Student("Amina", "S", "amina123", 2021, "21B030784", Degree.BACHELOR, Faculty.FIT, "IS");
		Student st3 = new Student("Lyaka", "B", "amina123", 2021, "1", Degree.BACHELOR, Faculty.FIT, "IS");
		Student st4 = new Student("Dari", "A", "amina123", 2021, "21B030754", Degree.BACHELOR, Faculty.FIT, "IS");
		Teacher t = new Teacher("Pakita", "S", "amina123", 2132334, 6.5, Faculty.FIT, 100, TeacherStatus.LECTURER);
		Teacher t1 = new Teacher("Bobur", "M", "amina123", 2132334, 4.5, Faculty.FIT, 60, TeacherStatus.LECTURER);
		Librarian l = new Librarian("Bakhyt", "Rakh", "123", 59000, 3.4);
		Course course = new Course("OOP", "123", 6, Faculty.FIT, 300, false, null);
		Course course1 = new Course("PP1", "527", 4, Faculty.FIT, 250, false, null);
		Course course2 = new Course("PP2", "935", 5, Faculty.FIT, 350, false, null);
		Course course3 = new Course("ALGO", "777", 4, Faculty.FIT, 150, false, null);
		Database.getDatabase().getUsers().add(a);
		Database.getDatabase().getUsers().add(m);
		Database.getDatabase().getUsers().add(st2);
		Database.getDatabase().getUsers().add(st3);
		Database.getDatabase().getUsers().add(st4);
		Database.getDatabase().getUsers().add(t);
		Database.getDatabase().getUsers().add(t1);
		Database.getDatabase().getUsers().add(l);
		Database.getDatabase().getCourses().add(course);
		Database.getDatabase().getCourses().add(course1);
		Database.getDatabase().getCourses().add(course2);
		Database.getDatabase().getCourses().add(course3);
//		for(Course coursee : Database.getDatabase().getCourses()) {
//			System.out.println(coursee);
//		}
		Intranet intranet = new Intranet();
		intranet.run();
	}

}
