package enums;

public enum TimeOfAttestation {
	ATTESTATION1, ATTESTATION2, FINAL
}
