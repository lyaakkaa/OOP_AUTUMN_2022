package menu;

import java.io.IOException;
import java.util.Date;

import classes.Admin;
import classes.Database;
import classes.User;

public class MenuAdmin extends MenuUser{
	
	private Admin admin;
	
	public MenuAdmin() {
		super.setMenu("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" +
				  "1.View users\n" + 
				  "2.Add user\n" + 
				  "3.Remove user\n"+
				  "4.Update user" + 
				  "5.View log files about user actions\n" +
				  "0.Exit\n" +  
				  "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
				);
	}
	
	public MenuAdmin(Admin admin) {
		this();
		this.admin = admin;
		this.hello();
	}

	@Override
	public void hello() {
		System.out.println("Login successfully, hello " + admin.getName());
		Database.getDatabase().addTimeOfSignIn("Admin " + admin.getName() + " " + admin.getSurname() + "logged in at " + new Date().toString());
	}



	@Override
	public boolean choosingAction(String act) throws IOException, InterruptedException {
		if(act == "1") this.viewUsers();
		else if(act == "2") this.addUser();
		else if(act == "3") this.removeUser();
		else if(act == "4") this.updateUser();
		else if(act == "5") this.viewTimeOfSignIn();
		else if (act == "0"){
			System.out.println("Goodbye! " + admin.getName() + admin.getSurname());
            return false;
		}
		else {
			System.out.println("You chose the wrong action, try again");
			return true;
		}
		
		return true;
	}
	
	public void viewUsers() {
		int index = 1;
		for(User u: admin.viewUsers()) {
			System.out.println(index + ")" + u);
		}
	}
	
	public void addUser() throws IOException, InterruptedException{
		
		
	}

}
