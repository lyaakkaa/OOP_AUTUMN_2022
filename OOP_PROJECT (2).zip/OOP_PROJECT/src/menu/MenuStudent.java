package menu;

import java.io.IOException;
import java.util.Date;

import classes.Database;
import classes.Student;

public class MenuStudent extends MenuUser{
	private Student student;
	
	public MenuStudent() {
		super.setMenu("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" +
					  "1.View data about me\n" + 
					  "2.View all courses\n" + 
					  "3.Register for a course\n"+
					  "4.View transcript\n" +
					  "5.Download transcript\n" + 
					  "6.Rate teacher\n" +
					  "7.View news\n" + 
					  "8.Take a book\n" + 
					  "0.Exit" +
					  "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n"
		);
		
	}
	
	public MenuStudent(Student student) {
		this();
		this.student = student;
		hello();
	}

	@Override
	public void hello() {
		System.out.println("Login successfully, hello " + student.getName());
		Database.getDatabase().addTimeOfSignIn("Student " + student.getName() + " " + student.getSurname() + "logged in at " + new Date().toString());
		
	}

	@Override
	public boolean choosingAction(String act) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		return false;
	}
	
	

}
