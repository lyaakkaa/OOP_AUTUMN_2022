package classes;

import enums.ManagerType;

@SuppressWarnings("serial")
public class Manager extends Employee{
private ManagerType managerType;
	
	public Manager() {
		super();
	}
	
	public Manager(String name, String surname, String password, int salary, double workExperience, ManagerType managerType) {
		super(name, surname, password, salary, workExperience);
		this.setManagerType(managerType);
	}

	public ManagerType getManagerType() {
		return managerType;
	}

	public void setManagerType(ManagerType managerType) {
		this.managerType = managerType;
	}
	
	public void addCourse(Course course) {
		Database.getDatabase().addCourses(course);
	}
	
	public void deleteCourse(Course course) {
		Database.getDatabase().deleteCourses(course);
	}

}
