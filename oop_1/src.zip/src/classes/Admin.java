package classes;

import java.util.Vector;

@SuppressWarnings("serial")
public class Admin extends Employee{
	public Admin() {}
	
	public Admin(String name, String surname, String password, int salary, double workExperience) {
		super(name, surname, password, salary, workExperience);
	}
	
	public void addUser(User user) {
		Database.getDatabase().addUser(user);
	}
	
	public void removeUser(User user) {
		Database.getDatabase().removeUser(user);
	}
	
	public Vector <User> viewUsers(){
		return Database.getDatabase().getUsers();
	}
	
	public Vector<String> getTimeOfSignIn (){
		return Database.getDatabase().getTimeOfSignIn();
	}

	
	
	

}
