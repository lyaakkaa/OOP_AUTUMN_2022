package classes;

public class Message {

}
