package classes;

import java.io.*;
import java.util.HashMap;
import java.util.Vector;

import enums.*;
import other.Book;

@SuppressWarnings("serial")
public final class Database implements Serializable{
	private static Database database;
	
	private static Vector<User> users;
	
	private static Vector<Course> courses;
	
	private static Vector<Faculty> faculties;
	
	private static Vector<Message> messages;
	
	private static Vector<String> timeOfSignIn;
	
	private static Vector <News> news;

	private static HashMap<Student, Course> permissionOfRegistrationCourse;
	
	private static HashMap <Book, Integer> books = new HashMap <Book, Integer> ();
	
	private Database(){
		users = new Vector<User>();
		courses = new Vector<Course>();
		faculties = new Vector<Faculty>();
		messages = new Vector<Message>();
		timeOfSignIn = new Vector<String>();
		news =  new Vector<News>();
		permissionOfRegistrationCourse = new HashMap <Student, Course>();
		books = new HashMap <Book, Integer>();
	}
	
	public static Database getDatabase() {
		if(database == null) {
			database = new Database();
		}
		return database;
	}
	
	public void addUser(User u) {
		users.add(u);
	}
	
	public void removeUser(User u) {
		users.remove(u);
	}

	public Vector<User> getUsers() {
		return users;
	}

	public void setUsers(Vector<User> users) {
		Database.users = users;
	}

	public Vector<Course> getCourses() {
		return courses;
	}

	public void addCourses(Course course) {
		Database.courses.add(course);
	}
	
	public void deleteCourses(Course course) {
		Database.courses.remove(course);
	}

	public Vector<Faculty> getFaculties() {
		return faculties;
	}

	public void setFaculties(Vector<Faculty> faculties) {
		Database.faculties = faculties;
	}

	public Vector<Message> getMessages() {
		return messages;
	}

	public void setMessages(Vector<Message> messages) {
		Database.messages = messages;
	}

	public Vector<String> getTimeOfSignIn() {
		return timeOfSignIn;
	}

	public void setTimeOfSignIn(Vector<String> timeOfSignIn) {
		Database.timeOfSignIn = timeOfSignIn;
	}

	public Vector<News> getNews() {
		return news;
	}

	public void setNews(Vector<News> news) {
		Database.news = news;
	}

	public HashMap<Student, Course> getPermissionOfRegistrationCourse() {
		return permissionOfRegistrationCourse;
	}

	public void setPermissionOfRegistrationCourse(HashMap<Student, Course> permissionOfRegistrationCourse) {
		Database.permissionOfRegistrationCourse = permissionOfRegistrationCourse;
	}

	public HashMap<Book, Integer> getBooks() {
		return books;
	}

	public void setBooks(HashMap<Book, Integer> books) {
		Database.books = books;
	}

	public void setDatabase(Database database) {
		Database.database = database;
	}
	
	
	
	
	
	
	

}
