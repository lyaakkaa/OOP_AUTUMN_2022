package classes;

public class Book {

}
