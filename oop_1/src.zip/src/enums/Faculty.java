package enums;


public enum Faculty {
    FIT, FGGE, ISE, FGE, FEOG, BS, KMA, CCE
}