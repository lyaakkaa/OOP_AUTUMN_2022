package classes;

import java.io.Serializable;


@SuppressWarnings("serial")
public class Transcript implements Serializable{
	private Student student;
	
	public Transcript(Student student) {
		this.setStudent(student);
	}

	public Double calculateGPA() {
		// TODO Auto-generated method stub
		return null;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}
 
}
