package menu;

import java.io.IOException;

public class MenuLibrarian extends MenuUser {

	@Override
	public void hello() {
		// TODO Auto-generated method stub

	}

	@Override
	public boolean choosingAction(String act) throws IOException, InterruptedException {
		// TODO Auto-generated method stub
		return false;
	}

}
