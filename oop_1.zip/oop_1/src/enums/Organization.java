package enums;

public enum Organization {
	OSIT, ARTHOUSE, BCL
}
