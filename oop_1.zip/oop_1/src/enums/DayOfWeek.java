package enums;

public enum DayOfWeek {
	MON, TUE, WED, THU, FRI, SAT, SUN
}
