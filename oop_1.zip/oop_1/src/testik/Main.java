package testik;

import java.io.IOException;

import exceptions.WrongLoginException;

public class Main {
	public static void main(String[] args) throws InterruptedException, IOException, WrongLoginException{
		Intranet intranet = new Intranet();
		intranet.run();
	}


}
