package enums;

public enum MessageType {
    LETTER,
    REQUEST
}