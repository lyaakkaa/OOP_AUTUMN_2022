package enums;

public enum FacultyName {
	FIT,
	GEF,
	SECMC,
	FOGI,
	BS,
	KMA
}