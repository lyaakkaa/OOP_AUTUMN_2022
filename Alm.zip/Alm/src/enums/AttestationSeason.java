package enums;

public enum AttestationSeason {
	FALL,
	SPRING
}
