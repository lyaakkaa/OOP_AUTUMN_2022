package enums;

public enum Degree {
	BACHELOR,
	MASTER,
	PHD
}
