package enums;

public enum TeacherTitle {
	TUTOR,
	LECTOR,
	SENIOR_LECTOR,
	PROFESSOR,
	ASSOCIATIVE_PROFESSOR
}