package enums;

public enum YearOfStudy {
	FIRST,
	SECOND,
	THIRD,
	FOURTH,
	EXTRA
}