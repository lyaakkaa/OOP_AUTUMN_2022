package enums;
public enum LessonType {
	LECTURE,
	PRACTICE,
	LAB
}