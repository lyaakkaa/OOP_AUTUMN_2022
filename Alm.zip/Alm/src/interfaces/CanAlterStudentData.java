package interfaces;

public interface CanAlterStudentData extends CanAlterUserData {}