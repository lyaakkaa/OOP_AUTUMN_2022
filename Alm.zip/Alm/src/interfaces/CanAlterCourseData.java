package interfaces;

public interface CanAlterCourseData {}