package interfaces;

public interface CanAlterUserData {}